const User = require("../models/User");
const News = require("../models/News");

// @desc Get logged-in user profile
// @route GET /api/users/profile
const getProfile = async (req, res) => {
  res.json(req.user);
};

// @desc Update logged-in user profile
// @route PUT /api/users/profile
const updateProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ message: "User not found" });

    user.name = req.body.name || user.name;
    user.bio = req.body.bio !== undefined ? req.body.bio : user.bio;

    if (req.body.password) {
      user.password = req.body.password;
    }

    if (req.file) {
      user.avatar = req.file.path;
    }

    const updatedUser = await user.save();

    res.json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      bio: updatedUser.bio,
      avatar: updatedUser.avatar,
      role: updatedUser.role,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc Get news created by logged-in user
// @route GET /api/users/my-news
const getMyNews = async (req, res) => {
  try {
    const news = await News.find({ author: req.user._id }).sort({ createdAt: -1 });
    res.json(news);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getProfile, updateProfile, getMyNews };
