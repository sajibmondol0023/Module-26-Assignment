const News = require("../models/News");

const makeSlug = (title) =>
  title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") +
  "-" +
  Date.now().toString(36);

// @desc Get all news (with pagination, search, category filter)
// @route GET /api/news
const getAllNews = async (req, res) => {
  try {
    const { page = 1, limit = 9, category, search } = req.query;
    const query = {};

    if (category && category !== "All") query.category = category;
    if (search) query.$text = { $search: search };

    const news = await News.find(query)
      .populate("author", "name avatar")
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    const total = await News.countDocuments(query);

    res.json({
      news,
      totalPages: Math.ceil(total / limit),
      currentPage: Number(page),
      total,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc Get top 6 news (most viewed / latest) for homepage
// @route GET /api/news/top
const getTopNews = async (req, res) => {
  try {
    const news = await News.find()
      .populate("author", "name avatar")
      .sort({ views: -1, createdAt: -1 })
      .limit(6);
    res.json(news);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc Get latest news for homepage sections
// @route GET /api/news/latest
const getLatestNews = async (req, res) => {
  try {
    const news = await News.find()
      .populate("author", "name avatar")
      .sort({ createdAt: -1 })
      .limit(8);
    res.json(news);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc Get single news by slug
// @route GET /api/news/:slug
const getNewsBySlug = async (req, res) => {
  try {
    const news = await News.findOneAndUpdate(
      { slug: req.params.slug },
      { $inc: { views: 1 } },
      { new: true }
    ).populate("author", "name avatar bio");

    if (!news) return res.status(404).json({ message: "News not found" });

    const related = await News.find({
      category: news.category,
      _id: { $ne: news._id },
    })
      .limit(4)
      .select("title slug image createdAt");

    res.json({ news, related });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc Create news
// @route POST /api/news
const createNews = async (req, res) => {
  try {
    const { title, summary, content, category, featured } = req.body;
    if (!title || !summary || !content) {
      return res.status(400).json({ message: "Please fill all required fields" });
    }

    const news = await News.create({
      title,
      slug: makeSlug(title),
      summary,
      content,
      category,
      featured: featured === "true" || featured === true,
      image: req.file ? req.file.path : "",
      author: req.user._id,
    });

    res.status(201).json(news);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc Update news (owner only)
// @route PUT /api/news/:id
const updateNews = async (req, res) => {
  try {
    const news = await News.findById(req.params.id);
    if (!news) return res.status(404).json({ message: "News not found" });

    if (news.author.toString() !== req.user._id.toString() && req.user.role !== "admin") {
      return res.status(403).json({ message: "Not authorized to edit this news" });
    }

    const { title, summary, content, category, featured } = req.body;

    news.title = title || news.title;
    news.summary = summary || news.summary;
    news.content = content || news.content;
    news.category = category || news.category;
    if (featured !== undefined) news.featured = featured === "true" || featured === true;
    if (req.file) news.image = req.file.path;

    const updated = await news.save();
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc Delete news (owner only)
// @route DELETE /api/news/:id
const deleteNews = async (req, res) => {
  try {
    const news = await News.findById(req.params.id);
    if (!news) return res.status(404).json({ message: "News not found" });

    if (news.author.toString() !== req.user._id.toString() && req.user.role !== "admin") {
      return res.status(403).json({ message: "Not authorized to delete this news" });
    }

    await news.deleteOne();
    res.json({ message: "News deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getAllNews,
  getTopNews,
  getLatestNews,
  getNewsBySlug,
  createNews,
  updateNews,
  deleteNews,
};
