const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const upload = require("../middleware/upload");
const { getProfile, updateProfile, getMyNews } = require("../controllers/userController");

router.get("/profile", protect, getProfile);
router.put("/profile", protect, upload.single("avatar"), updateProfile);
router.get("/my-news", protect, getMyNews);

module.exports = router;
