const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/auth");
const upload = require("../middleware/upload");
const {
  getAllNews,
  getTopNews,
  getLatestNews,
  getNewsBySlug,
  createNews,
  updateNews,
  deleteNews,
} = require("../controllers/newsController");

router.get("/", getAllNews);
router.get("/top", getTopNews);
router.get("/latest", getLatestNews);
router.post("/", protect, upload.single("image"), createNews);
router.get("/:slug", getNewsBySlug);
router.put("/id/:id", protect, upload.single("image"), updateNews);
router.delete("/id/:id", protect, deleteNews);

module.exports = router;
