// Simple seeder to populate sample users and news for testing.
// Run: node seed/seed.js
require("dotenv").config();
const mongoose = require("mongoose");
const connectDB = require("../config/db");
const User = require("../models/User");
const News = require("../models/News");

const categories = ["National", "International", "Sports", "Technology", "Entertainment", "Business", "Politics", "Health"];

const slugify = (title) =>
  title.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") + "-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

const run = async () => {
  await connectDB();

  await News.deleteMany();
  await User.deleteMany();

  const admin = await User.create({
    name: "Admin Editor",
    email: "admin@dailypulse.com",
    password: "admin123",
    role: "admin",
    bio: "Chief Editor at DailyPulse",
  });

  const items = [];
  for (let i = 1; i <= 12; i++) {
    const cat = categories[i % categories.length];
    items.push({
      title: `Sample ${cat} Headline Story #${i}`,
      slug: slugify(`Sample ${cat} Headline Story ${i}`),
      summary: `This is a short summary for sample news article number ${i} in the ${cat} category.`,
      content: `Full article body for sample news #${i}. Lorem ipsum dolor sit amet, consectetur adipiscing elit. This content can be replaced with real news content once real users start publishing.`,
      category: cat,
      image: `https://picsum.photos/seed/news${i}/800/500`,
      author: admin._id,
      views: Math.floor(Math.random() * 500),
      featured: i <= 3,
    });
  }
  await News.insertMany(items);

  console.log("Seed data created. Admin login: admin@dailypulse.com / admin123");
  process.exit();
};

run();
