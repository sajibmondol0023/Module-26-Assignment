import { create } from "zustand";
import api from "../api/axios";

const useNewsStore = create((set, get) => ({
  news: [],
  topNews: [],
  latestNews: [],
  myNews: [],
  currentNews: null,
  related: [],
  totalPages: 1,
  currentPage: 1,
  loading: false,
  error: null,

  fetchTopNews: async () => {
    try {
      const res = await api.get("/news/top");
      set({ topNews: res.data });
    } catch (err) {
      console.error(err);
    }
  },

  fetchLatestNews: async () => {
    try {
      const res = await api.get("/news/latest");
      set({ latestNews: res.data });
    } catch (err) {
      console.error(err);
    }
  },

  fetchAllNews: async ({ page = 1, category = "All", search = "" } = {}) => {
    set({ loading: true, error: null });
    try {
      const res = await api.get("/news", { params: { page, category, search } });
      set({
        news: res.data.news,
        totalPages: res.data.totalPages,
        currentPage: res.data.currentPage,
        loading: false,
      });
    } catch (err) {
      set({ error: "Failed to load news", loading: false });
    }
  },

  fetchNewsBySlug: async (slug) => {
    set({ loading: true, error: null, currentNews: null });
    try {
      const res = await api.get(`/news/${slug}`);
      set({ currentNews: res.data.news, related: res.data.related, loading: false });
    } catch (err) {
      set({ error: "News not found", loading: false });
    }
  },

  fetchMyNews: async () => {
    set({ loading: true });
    try {
      const res = await api.get("/users/my-news");
      set({ myNews: res.data, loading: false });
    } catch (err) {
      set({ loading: false });
    }
  },

  createNews: async (formData) => {
    try {
      const res = await api.post("/news", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      return { success: true, data: res.data };
    } catch (err) {
      return { success: false, message: err.response?.data?.message || "Failed to create news" };
    }
  },

  updateNews: async (id, formData) => {
    try {
      const res = await api.put(`/news/id/${id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      return { success: true, data: res.data };
    } catch (err) {
      return { success: false, message: err.response?.data?.message || "Failed to update news" };
    }
  },

  deleteNews: async (id) => {
    try {
      await api.delete(`/news/id/${id}`);
      set((state) => ({ myNews: state.myNews.filter((n) => n._id !== id) }));
      return { success: true };
    } catch (err) {
      return { success: false, message: err.response?.data?.message || "Failed to delete news" };
    }
  },
}));

export default useNewsStore;
