import { create } from "zustand";
import { persist } from "zustand/middleware";
import api from "../api/axios";

const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      loading: false,
      error: null,

      register: async (data) => {
        set({ loading: true, error: null });
        try {
          const res = await api.post("/auth/register", data);
          set({ user: res.data, loading: false });
          return { success: true };
        } catch (err) {
          const message = err.response?.data?.message || "Registration failed";
          set({ error: message, loading: false });
          return { success: false, message };
        }
      },

      login: async (data) => {
        set({ loading: true, error: null });
        try {
          const res = await api.post("/auth/login", data);
          set({ user: res.data, loading: false });
          return { success: true };
        } catch (err) {
          const message = err.response?.data?.message || "Login failed";
          set({ error: message, loading: false });
          return { success: false, message };
        }
      },

      logout: () => set({ user: null }),

      updateProfile: async (formData) => {
        set({ loading: true, error: null });
        try {
          const res = await api.put("/users/profile", formData, {
            headers: { "Content-Type": "multipart/form-data" },
          });
          set((state) => ({
            user: { ...state.user, ...res.data },
            loading: false,
          }));
          return { success: true };
        } catch (err) {
          const message = err.response?.data?.message || "Update failed";
          set({ error: message, loading: false });
          return { success: false, message };
        }
      },
    }),
    { name: "auth-storage" }
  )
);

export default useAuthStore;
