import React from "react";
import { Link } from "react-router-dom";

const NotFound = () => (
  <div className="container text-center mt-5 mb-5">
    <h1 className="display-1 fw-bold">404</h1>
    <p className="lead">Page not found.</p>
    <Link to="/" className="btn btn-brand">Go Home</Link>
  </div>
);

export default NotFound;
