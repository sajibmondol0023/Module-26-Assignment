import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import useNewsStore from "../store/newsStore";
import api from "../api/axios";

const categories = ["National", "International", "Sports", "Technology", "Entertainment", "Business", "Politics", "Health"];

const CreateNews = () => {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const { createNews, updateNews } = useNewsStore();

  const [form, setForm] = useState({
    title: "",
    summary: "",
    content: "",
    category: "National",
    featured: false,
  });
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (isEdit) {
      // Load existing news for editing (owner's own news list is cheapest source)
      api.get("/users/my-news").then((res) => {
        const item = res.data.find((n) => n._id === id);
        if (item) {
          setForm({
            title: item.title,
            summary: item.summary,
            content: item.content,
            category: item.category,
            featured: item.featured,
          });
          setPreview(item.image);
        }
      });
    }
  }, [id]);

  const handleImage = (e) => {
    const file = e.target.files[0];
    setImage(file);
    if (file) setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    const fd = new FormData();
    fd.append("title", form.title);
    fd.append("summary", form.summary);
    fd.append("content", form.content);
    fd.append("category", form.category);
    fd.append("featured", form.featured);
    if (image) fd.append("image", image);

    const res = isEdit ? await updateNews(id, fd) : await createNews(fd);
    setSubmitting(false);

    if (res.success) {
      navigate("/dashboard");
    } else {
      setError(res.message);
    }
  };

  return (
    <div className="container mt-4 mb-5" style={{ maxWidth: 700 }}>
      <h3 className="mb-4">{isEdit ? "Edit News" : "Publish New News"}</h3>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Title</label>
          <input className="form-control" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        </div>
        <div className="mb-3">
          <label className="form-label">Category</label>
          <select className="form-select" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
            {categories.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="mb-3">
          <label className="form-label">Summary</label>
          <textarea className="form-control" rows="2" required value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} />
        </div>
        <div className="mb-3">
          <label className="form-label">Full Content</label>
          <textarea className="form-control" rows="8" required value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} />
        </div>
        <div className="mb-3">
          <label className="form-label">Banner Image</label>
          <input type="file" accept="image/*" className="form-control" onChange={handleImage} />
          {preview && <img src={preview} alt="preview" className="mt-2 rounded" style={{ maxHeight: 180 }} />}
        </div>
        <div className="form-check mb-3">
          <input type="checkbox" className="form-check-input" id="featured" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} />
          <label className="form-check-label" htmlFor="featured">Mark as Featured</label>
        </div>
        <button className="btn btn-brand" disabled={submitting}>
          {submitting ? "Saving..." : isEdit ? "Update News" : "Publish News"}
        </button>
      </form>
    </div>
  );
};

export default CreateNews;
