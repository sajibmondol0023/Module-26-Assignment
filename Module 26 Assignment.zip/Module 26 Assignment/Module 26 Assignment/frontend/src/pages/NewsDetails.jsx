import React, { useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import useNewsStore from "../store/newsStore";

const fallbackImg = "https://placehold.co/900x500?text=DailyPulse+News";

const NewsDetails = () => {
  const { slug } = useParams();
  const { currentNews, related, loading, error, fetchNewsBySlug } = useNewsStore();

  useEffect(() => {
    fetchNewsBySlug(slug);
    window.scrollTo(0, 0);
  }, [slug]);

  if (loading) return <div className="container mt-5"><p>Loading...</p></div>;
  if (error || !currentNews) return <div className="container mt-5"><p>News not found.</p></div>;

  const news = currentNews;

  return (
    <div className="container mt-4 mb-5">
      <div className="row">
        <div className="col-lg-8">
          <span className="badge category-badge mb-2">{news.category}</span>
          <h1 className="h3">{news.title}</h1>
          <div className="d-flex align-items-center gap-3 text-muted small mb-3">
            <span>By {news.author?.name || "Staff"}</span>
            <span>{new Date(news.createdAt).toLocaleString()}</span>
            <span>{news.views} views</span>
          </div>
          <img src={news.image || fallbackImg} alt={news.title} className="img-fluid rounded mb-4 w-100" style={{ maxHeight: 450, objectFit: "cover" }} />
          <p className="lead">{news.summary}</p>
          <div className="news-content" style={{ whiteSpace: "pre-line" }}>{news.content}</div>
        </div>

        <div className="col-lg-4">
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-dark text-white">Related News</div>
            <div className="list-group list-group-flush">
              {related.length === 0 && <p className="p-3 text-muted small mb-0">No related news.</p>}
              {related.map((r) => (
                <Link key={r._id} to={`/news/${r.slug}`} className="list-group-item list-group-item-action d-flex gap-2 align-items-center">
                  <img src={r.image || fallbackImg} width="60" height="45" style={{ objectFit: "cover" }} className="rounded" alt={r.title} />
                  <span className="small">{r.title}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewsDetails;
