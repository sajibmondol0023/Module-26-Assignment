import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import useNewsStore from "../store/newsStore";
import NewsCard from "../components/NewsCard";

const categories = ["All", "National", "International", "Sports", "Technology", "Entertainment", "Business", "Politics", "Health"];

const News = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const category = searchParams.get("category") || "All";
  const search = searchParams.get("search") || "";
  const page = Number(searchParams.get("page")) || 1;

  const { news, totalPages, currentPage, loading, fetchAllNews } = useNewsStore();

  useEffect(() => {
    fetchAllNews({ page, category, search });
  }, [page, category, search]);

  const handleCategory = (c) => {
    setSearchParams({ category: c, page: 1 });
  };

  const goToPage = (p) => {
    const params = { page: p };
    if (category !== "All") params.category = category;
    if (search) params.search = search;
    setSearchParams(params);
  };

  return (
    <div className="container mt-4 mb-5">
      <h3 className="border-start border-4 border-danger ps-2 mb-4">
        {search ? `Search results for "${search}"` : category === "All" ? "All News" : `${category} News`}
      </h3>

      <div className="d-flex flex-wrap gap-2 mb-4">
        {categories.map((c) => (
          <button
            key={c}
            className={`btn btn-sm ${category === c ? "btn-brand" : "btn-outline-secondary"}`}
            onClick={() => handleCategory(c)}
          >
            {c}
          </button>
        ))}
      </div>

      {loading ? (
        <p>Loading news...</p>
      ) : news.length === 0 ? (
        <p className="text-muted">No news found.</p>
      ) : (
        <div className="row g-4">
          {news.map((n) => (
            <div className="col-md-4" key={n._id}>
              <NewsCard news={n} />
            </div>
          ))}
        </div>
      )}

      {totalPages > 1 && (
        <nav className="mt-4">
          <ul className="pagination justify-content-center">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <li key={p} className={`page-item ${currentPage === p ? "active" : ""}`}>
                <button className="page-link" onClick={() => goToPage(p)}>{p}</button>
              </li>
            ))}
          </ul>
        </nav>
      )}
    </div>
  );
};

export default News;
