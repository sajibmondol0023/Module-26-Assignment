import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import useAuthStore from "../store/authStore";
import useNewsStore from "../store/newsStore";

const Dashboard = () => {
  const { user, updateProfile, loading } = useAuthStore();
  const { myNews, fetchMyNews, deleteNews } = useNewsStore();

  const [tab, setTab] = useState("news");
  const [profileForm, setProfileForm] = useState({ name: user?.name || "", bio: user?.bio || "", password: "" });
  const [avatar, setAvatar] = useState(null);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    fetchMyNews();
  }, []);

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    setMsg("");
    const fd = new FormData();
    fd.append("name", profileForm.name);
    fd.append("bio", profileForm.bio);
    if (profileForm.password) fd.append("password", profileForm.password);
    if (avatar) fd.append("avatar", avatar);

    const res = await updateProfile(fd);
    setMsg(res.success ? "Profile updated successfully." : res.message);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this news article?")) {
      await deleteNews(id);
    }
  };

  return (
    <div className="container mt-4 mb-5">
      <h3 className="mb-4">Welcome, {user?.name}</h3>

      <ul className="nav nav-tabs mb-4">
        <li className="nav-item">
          <button className={`nav-link ${tab === "news" ? "active" : ""}`} onClick={() => setTab("news")}>My News</button>
        </li>
        <li className="nav-item">
          <button className={`nav-link ${tab === "profile" ? "active" : ""}`} onClick={() => setTab("profile")}>Edit Profile</button>
        </li>
      </ul>

      {tab === "news" && (
        <div>
          <div className="d-flex justify-content-between mb-3">
            <h5>My Published News ({myNews.length})</h5>
            <Link to="/create-news" className="btn btn-brand btn-sm">+ Publish New News</Link>
          </div>
          {myNews.length === 0 ? (
            <p className="text-muted">You haven't published any news yet.</p>
          ) : (
            <div className="table-responsive">
              <table className="table table-hover align-middle bg-white">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Views</th>
                    <th>Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {myNews.map((n) => (
                    <tr key={n._id}>
                      <td><Link to={`/news/${n.slug}`}>{n.title}</Link></td>
                      <td><span className="badge category-badge">{n.category}</span></td>
                      <td>{n.views}</td>
                      <td>{new Date(n.createdAt).toLocaleDateString()}</td>
                      <td>
                        <Link to={`/edit-news/${n._id}`} className="btn btn-sm btn-outline-primary me-2">Edit</Link>
                        <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(n._id)}>Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {tab === "profile" && (
        <div className="card p-4" style={{ maxWidth: 500 }}>
          {msg && <div className="alert alert-info py-2">{msg}</div>}
          <form onSubmit={handleProfileSubmit}>
            <div className="text-center mb-3">
              <img
                src={user?.avatar || "https://ui-avatars.com/api/?name=" + user?.name}
                alt="avatar"
                className="rounded-circle"
                width="90"
                height="90"
                style={{ objectFit: "cover" }}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Change Avatar</label>
              <input type="file" accept="image/*" className="form-control" onChange={(e) => setAvatar(e.target.files[0])} />
            </div>
            <div className="mb-3">
              <label className="form-label">Name</label>
              <input className="form-control" value={profileForm.name} onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })} />
            </div>
            <div className="mb-3">
              <label className="form-label">Bio</label>
              <textarea className="form-control" rows="3" value={profileForm.bio} onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })} />
            </div>
            <div className="mb-3">
              <label className="form-label">New Password (optional)</label>
              <input type="password" className="form-control" placeholder="Leave blank to keep current password" onChange={(e) => setProfileForm({ ...profileForm, password: e.target.value })} />
            </div>
            <button className="btn btn-brand" disabled={loading}>{loading ? "Saving..." : "Save Changes"}</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
