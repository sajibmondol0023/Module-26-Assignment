import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import useNewsStore from "../store/newsStore";
import NewsCard from "../components/NewsCard";

const fallbackImg = "https://placehold.co/900x500?text=DailyPulse+News";

const Home = () => {
  const { topNews, latestNews, fetchTopNews, fetchLatestNews } = useNewsStore();

  useEffect(() => {
    fetchTopNews();
    fetchLatestNews();
  }, []);

  const hero = topNews[0];
  const heroSide = topNews.slice(1, 5);
  const trending = topNews.slice(0, 6);

  return (
    <div>
      {/* Section 1: Hero / Breaking News */}
      <section className="container mt-4">
        <h4 className="border-start border-4 border-danger ps-2 mb-3">Breaking News</h4>
        {hero ? (
          <div className="row g-3">
            <div className="col-lg-7">
              <div className="card hero-card border-0 shadow-sm position-relative">
                <img src={hero.image || fallbackImg} className="card-img" alt={hero.title} />
                <div className="card-img-overlay d-flex flex-column justify-content-end" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.8), transparent)" }}>
                  <span className="badge category-badge mb-2 align-self-start">{hero.category}</span>
                  <Link to={`/news/${hero.slug}`} className="text-white text-decoration-none">
                    <h2 className="h4">{hero.title}</h2>
                  </Link>
                  <p className="text-white-50 small">{hero.summary?.slice(0, 120)}...</p>
                </div>
              </div>
            </div>
            <div className="col-lg-5">
              <div className="row g-3">
                {heroSide.map((n) => (
                  <div className="col-6" key={n._id}>
                    <NewsCard news={n} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <p className="text-muted">No news published yet.</p>
        )}
      </section>

      {/* Section 2: Top 6 News (Trending) */}
      <section className="container mt-5">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h4 className="border-start border-4 border-danger ps-2 mb-0">Top 6 Trending News</h4>
          <Link to="/news" className="btn btn-sm btn-outline-dark">View All</Link>
        </div>
        <div className="row g-4">
          {trending.map((n) => (
            <div className="col-md-4" key={n._id}>
              <NewsCard news={n} />
            </div>
          ))}
        </div>
      </section>

      {/* Section 3: Latest News */}
      <section className="container mt-5">
        <h4 className="border-start border-4 border-danger ps-2 mb-3">Latest News</h4>
        <div className="row g-4">
          {latestNews.map((n) => (
            <div className="col-md-3" key={n._id}>
              <NewsCard news={n} />
            </div>
          ))}
        </div>
      </section>

      {/* Section 4: Categories Highlight */}
      <section className="container mt-5">
        <h4 className="border-start border-4 border-danger ps-2 mb-3">Explore Categories</h4>
        <div className="row g-3 text-center">
          {["Sports", "Technology", "Business", "Entertainment", "Politics", "Health"].map((c) => (
            <div className="col-6 col-md-2" key={c}>
              <Link to={`/news?category=${c}`} className="btn btn-outline-danger w-100 py-3">
                {c}
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Section 5: Call To Action */}
      <section className="bg-dark text-white text-center py-5 mt-5">
        <div className="container">
          <h3>Have a story to share?</h3>
          <p className="text-white-50">Join DailyPulse and publish your own news article to our readers.</p>
          <Link to="/register" className="btn btn-brand">Join Now</Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
