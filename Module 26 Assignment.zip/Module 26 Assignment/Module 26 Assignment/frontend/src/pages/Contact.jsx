import React, { useState } from "react";

const Contact = () => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Note: no backend endpoint required by the assignment for contact form.
    // This can be wired to a /api/contact endpoint later if needed.
    setSent(true);
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <div className="container mt-5 mb-5">
      <div className="row">
        <div className="col-lg-6 mb-4">
          <h3 className="mb-3">Contact Us</h3>
          <p className="text-muted">Have feedback, a news tip, or a question? Send us a message and our editorial team will get back to you.</p>
          <ul className="list-unstyled">
            <li><strong>Address:</strong> Dhaka, Bangladesh</li>
            <li><strong>Email:</strong> support@dailypulse.com</li>
            <li><strong>Phone:</strong> +880 1XXX-XXXXXX</li>
          </ul>
        </div>
        <div className="col-lg-6">
          <div className="card shadow-sm p-4">
            {sent && <div className="alert alert-success">Message sent! We'll get back to you soon.</div>}
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label">Name</label>
                <input className="form-control" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div className="mb-3">
                <label className="form-label">Email</label>
                <input type="email" className="form-control" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="mb-3">
                <label className="form-label">Message</label>
                <textarea className="form-control" rows="5" required value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
              </div>
              <button className="btn btn-brand w-100">Send Message</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
