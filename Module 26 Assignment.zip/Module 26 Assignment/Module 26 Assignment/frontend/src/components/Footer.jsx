import React from "react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="footer pt-5 pb-3 mt-5">
      <div className="container">
        <div className="row">
          <div className="col-md-4 mb-4">
            <h4 className="text-white">DailyPulse</h4>
            <p>Your trusted source for the latest national and international news, technology updates, sports and more.</p>
          </div>
          <div className="col-md-4 mb-4">
            <h5 className="text-white">Quick Links</h5>
            <ul className="list-unstyled">
              <li><Link to="/">Home</Link></li>
              <li><Link to="/news">All News</Link></li>
              <li><Link to="/contact">Contact Us</Link></li>
              <li><Link to="/login">Login</Link></li>
            </ul>
          </div>
          <div className="col-md-4 mb-4">
            <h5 className="text-white">Follow Us</h5>
            <p>Facebook · Twitter · Instagram · YouTube</p>
          </div>
        </div>
        <hr className="border-secondary" />
        <p className="text-center mb-0 small">&copy; {new Date().getFullYear()} DailyPulse News Portal. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
