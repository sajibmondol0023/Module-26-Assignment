import React from "react";
import { Link } from "react-router-dom";

const fallbackImg = "https://placehold.co/600x400?text=DailyPulse+News";

const NewsCard = ({ news }) => {
  return (
    <div className="card news-card h-100 shadow-sm border-0">
      <img src={news.image || fallbackImg} className="card-img-top" alt={news.title} />
      <div className="card-body d-flex flex-column">
        <span className="badge category-badge mb-2 align-self-start">{news.category}</span>
        <h5 className="card-title">
          <Link to={`/news/${news.slug}`} className="text-decoration-none text-dark">
            {news.title}
          </Link>
        </h5>
        <p className="card-text text-muted small flex-grow-1">
          {news.summary?.slice(0, 100)}{news.summary?.length > 100 ? "..." : ""}
        </p>
        <div className="d-flex justify-content-between align-items-center small text-muted">
          <span>{news.author?.name || "Staff"}</span>
          <span>{new Date(news.createdAt).toLocaleDateString()}</span>
        </div>
      </div>
    </div>
  );
};

export default NewsCard;
