import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api",
});

api.interceptors.request.use((config) => {
  const raw = localStorage.getItem("auth-storage");
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      const token = parsed?.state?.user?.token;
      if (token) config.headers.Authorization = `Bearer ${token}`;
    } catch (e) {}
  }
  return config;
});

export default api;
